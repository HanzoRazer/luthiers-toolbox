from __future__ import annotations

import logging
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import numpy as np

from body_isolation_result import BodyIsolationResult
from body_isolation_stage import BodyIsolationParams
from contour_stage import StageParams
from geometry_coach import CoachDecision  # reuse V1 type if needed

# Lazy import to avoid circular dependencies
try:
    from blueprint_view_segmenter import (
        BlueprintViewSegmenter,
        SegmentationResult,
        DetectedView,
    )
    MULTI_VIEW_AVAILABLE = True
except ImportError:
    MULTI_VIEW_AVAILABLE = False
    BlueprintViewSegmenter = None
    SegmentationResult = None
    DetectedView = None

logger = logging.getLogger(__name__)

CRITICAL_EXPORT_THRESHOLD = 0.30


@dataclass
class CoachV2Config:
    max_retries: int = 2
    epsilon: float = 0.03  # minimum score improvement to accept rerun

    # Trigger thresholds
    body_isolation_review_threshold: float = 0.45
    contour_target_threshold: float = 0.80
    severe_border_penalty_threshold: float = 0.5
    ownership_retry_threshold: float = 0.60

    # Multi-view blueprint detection settings
    enable_multi_view_detection: bool = True
    multi_view_score_threshold: float = 0.50  # min score to consider a view viable
    multi_view_min_area_ratio: float = 0.05   # min view area as fraction of image
    multi_view_max_views: int = 6             # max views to process

    # Retry profiles for body isolation
    body_retry_profiles: List[BodyIsolationParams] = field(
        default_factory=lambda: [
            BodyIsolationParams(profile="lower_bout_recovery"),
            BodyIsolationParams(profile="border_suppression"),
            BodyIsolationParams(profile="body_region_expansion"),
        ]
    )

    # Existing contour-stage retry profiles
    contour_retry_profiles: List[StageParams] = field(default_factory=list)


@dataclass
class CoachDecisionV2:
    # Actions: accept | rerun_body_isolation | rerun_contour_stage |
    #          segment_views | manual_review_required
    action: str
    reason: str
    notes: List[str] = field(default_factory=list)
    retry_count: int = 0

    body_retry_params: Optional[BodyIsolationParams] = None
    contour_retry_params: Optional[StageParams] = None

    original_body_score: Optional[float] = None
    original_contour_score: Optional[float] = None
    candidate_body_score: Optional[float] = None
    candidate_contour_score: Optional[float] = None

    # Multi-view segmentation results
    views_detected: int = 0
    selected_view_index: Optional[int] = None
    view_scores: Optional[List[float]] = None


class GeometryCoachV2:
    """
    Coach V2 widens scope from contour-only retries to body-ownership retries.

    Primary responsibilities:
      1. Inspect BodyIsolationResult
      2. Inspect ContourStageResult
      3. Choose the *next safest rerun target*
      4. Enforce guardrails:
         - max retries
         - monotonic improvement
         - no silent downgrade
         - terminal manual review state
    """

    def __init__(self, config: Optional[CoachV2Config] = None):
        self.config = config or CoachV2Config()

    def should_retry(
        self,
        *,
        body_result: BodyIsolationResult,
        contour_result: Any,
        retry_count: int = 0,
    ) -> bool:
        if retry_count >= self.config.max_retries:
            return False

        body_score = float(getattr(body_result, "completeness_score", 0.0))
        contour_score = float(getattr(contour_result, "best_score", 0.0))

        # Ownership gate — low ownership always warrants a retry attempt
        ownership_score = self._ownership_score(contour_result)
        if ownership_score is not None and ownership_score < self.config.ownership_retry_threshold:
            return True

        if contour_score < self.config.contour_target_threshold:
            return True

        if body_score < self.config.body_isolation_review_threshold:
            return True

        return False

    def decide(
        self,
        *,
        body_result: BodyIsolationResult,
        contour_result: Any,
        retry_count: int = 0,
    ) -> CoachDecisionV2:
        """
        Decide the next action without performing it.

        Priority:
          1. If body ownership is suspect, rerun body isolation first
          2. Else if contour score is weak and merge behavior is suspicious, rerun contour stage
          3. Else accept
          4. If retry budget exhausted and still weak -> manual review
        """
        body_score = float(getattr(body_result, "completeness_score", 0.0))
        contour_score = float(getattr(contour_result, "best_score", 0.0))

        # Rule 0: body ownership gate — fires before retry budget check so
        # the first ownership failure always gets a retry attempt.
        ownership_score = self._ownership_score(contour_result)
        if ownership_score is not None and ownership_score < self.config.ownership_retry_threshold:
            if retry_count < self.config.max_retries:
                params = self._choose_body_retry_profile(
                    retry_count,
                    preferred_profile="body_region_expansion",
                )
                if params is not None:
                    return CoachDecisionV2(
                        action="rerun_body_isolation",
                        reason=(
                            f"Contour failed body ownership gate "
                            f"({ownership_score:.3f} < {self.config.ownership_retry_threshold:.3f})."
                        ),
                        retry_count=retry_count,
                        body_retry_params=params,
                        original_body_score=body_score,
                        original_contour_score=contour_score,
                        notes=[
                            "Ownership failure suggests body region is incomplete or neck-heavy.",
                            "Forcing body isolation retry before contour-only retry.",
                        ],
                    )
            return CoachDecisionV2(
                action="manual_review_required",
                reason=(
                    f"Contour failed body ownership gate "
                    f"({ownership_score:.3f}) and no safe body retry remains."
                ),
                retry_count=retry_count,
                original_body_score=body_score,
                original_contour_score=contour_score,
                notes=["manual_review_required due to persistent body ownership failure"],
            )

        if retry_count >= self.config.max_retries:
            return CoachDecisionV2(
                action="manual_review_required",
                reason="Maximum retry budget exhausted.",
                retry_count=retry_count,
                original_body_score=body_score,
                original_contour_score=contour_score,
                notes=["Retries exhausted before reaching acceptable contour/body scores."],
            )

        # Rule A: lower bout likely missing -> body isolation first
        if body_result.lower_bout_missing_likely and body_score < self.config.body_isolation_review_threshold:
            params = self._choose_body_retry_profile(retry_count)
            return CoachDecisionV2(
                action="rerun_body_isolation",
                reason="Body isolation likely under-captured lower bout.",
                retry_count=retry_count,
                body_retry_params=params,
                original_body_score=body_score,
                original_contour_score=contour_score,
                notes=["Rule A fired: lower-bout recovery attempt."],
            )

        # Rule B: border contamination likely -> body isolation first
        if body_result.border_contact_likely and body_result.score_breakdown.border_contact_penalty >= self.config.severe_border_penalty_threshold:
            params = self._choose_body_retry_profile(retry_count)
            return CoachDecisionV2(
                action="rerun_body_isolation",
                reason="Body isolation likely contaminated by border/crop contact.",
                retry_count=retry_count,
                body_retry_params=params,
                original_body_score=body_score,
                original_contour_score=contour_score,
                notes=["Rule B fired: border-contact suppression attempt."],
            )

        # Rule C: contour-stage disagreement/merge suspicion -> contour retry
        if self._contour_retry_worthwhile(contour_result):
            params = self._choose_contour_retry_profile(retry_count)
            return CoachDecisionV2(
                action="rerun_contour_stage",
                reason="Contour plausibility is weak and alternate merge profile may improve election.",
                retry_count=retry_count,
                contour_retry_params=params,
                original_body_score=body_score,
                original_contour_score=contour_score,
                notes=["Rule C fired: contour retry based on pre/post disagreement or merge tradeoff."],
            )

        # Rule D: poor scores but no useful retry path
        if contour_score < CRITICAL_EXPORT_THRESHOLD or body_score < self.config.body_isolation_review_threshold:
            return CoachDecisionV2(
                action="manual_review_required",
                reason="Scores remain too low for safe autonomous correction.",
                retry_count=retry_count,
                original_body_score=body_score,
                original_contour_score=contour_score,
                notes=["No safe retry path selected."],
            )

        return CoachDecisionV2(
            action="accept",
            reason="Current body isolation and contour election are acceptable.",
            retry_count=retry_count,
            original_body_score=body_score,
            original_contour_score=contour_score,
        )

    def accept_candidate(
        self,
        *,
        original_body_result: BodyIsolationResult,
        original_contour_result: Any,
        candidate_body_result: Optional[BodyIsolationResult] = None,
        candidate_contour_result: Optional[Any] = None,
    ) -> bool:
        """
        Comparative acceptance gate.

        Accept a retry result only if:
          - contour score improved by epsilon OR
          - body score improved by epsilon without contour score degrading materially
        """
        old_body = float(getattr(original_body_result, "completeness_score", 0.0))
        old_contour = float(getattr(original_contour_result, "best_score", 0.0))

        new_body = float(getattr(candidate_body_result, "completeness_score", old_body))
        new_contour = float(getattr(candidate_contour_result, "best_score", old_contour))

        contour_improved = new_contour > (old_contour + self.config.epsilon)
        body_improved = new_body > (old_body + self.config.epsilon)

        # Prefer contour improvement; allow body improvement only if contour does not regress
        if contour_improved:
            return True

        if body_improved and new_contour >= old_contour:
            return True

        return False

    def evaluate(
        self,
        *,
        body_stage_runner: Any,
        contour_stage_runner: Any,
        image: Any,
        fg_mask: Any,
        original_image: Any,
        instrument_family: Any,
        geometry_authority: Any,
        contour_inputs: Dict[str, Any],
        body_result: BodyIsolationResult,
        contour_result: Any,
    ) -> Tuple[BodyIsolationResult, Any, CoachDecisionV2]:
        """
        Execute a guarded V2 retry loop.

        Expects:
          body_stage_runner.run(...)
          contour_stage_runner.run(...)

        Returns:
          (
            current_body_result,
            current_contour_result,
            coach_decision
          )

        The returned body/contour results are the accepted best-known results
        after any safe retries have been evaluated.
        """
        current_body = body_result
        current_contour = contour_result

        def _ensure_diag(obj: Any) -> Dict[str, Any]:
            diag = getattr(obj, "diagnostics", None)
            if diag is None:
                diag = {}
                setattr(obj, "diagnostics", diag)
            return diag

        def _profile_name(profile: Any) -> Optional[str]:
            if profile is None:
                return None
            name = getattr(profile, "profile", None)
            if name:
                return str(name)
            return getattr(profile, "__class__", type(profile)).__name__

        def _annotate_retry_attempt(
            contour_obj: Any,
            *,
            retry_reason: str,
            retry_profile_used: Optional[str],
            retry_iteration: int,
            score_before: Optional[float],
            score_after: Optional[float],
            ownership_score_before: Optional[float],
            ownership_score_after: Optional[float],
            ownership_ok_before: Optional[bool],
            ownership_ok_after: Optional[bool],
        ) -> None:
            diag = _ensure_diag(contour_obj)
            attempts = diag.setdefault("retry_attempts", [])
            delta = None
            ownership_delta = None
            if score_before is not None and score_after is not None:
                try:
                    delta = float(score_after) - float(score_before)
                except (TypeError, ValueError):
                    delta = None
            if ownership_score_before is not None and ownership_score_after is not None:
                try:
                    ownership_delta = float(ownership_score_after) - float(ownership_score_before)
                except (TypeError, ValueError):
                    ownership_delta = None
            attempts.append(
                {
                    "retry_reason": retry_reason,
                    "retry_profile_used": retry_profile_used,
                    "retry_iteration": retry_iteration,
                    "score_before": score_before,
                    "score_after": score_after,
                    "score_delta": delta,
                    "ownership_score_before": ownership_score_before,
                    "ownership_score_after": ownership_score_after,
                    "ownership_score_delta": ownership_delta,
                    "ownership_ok_before": ownership_ok_before,
                    "ownership_ok_after": ownership_ok_after,
                }
            )

        for retry_count in range(self.config.max_retries + 1):
            decision = self.decide(
                body_result=current_body,
                contour_result=current_contour,
                retry_count=retry_count,
            )

            if decision.action in ("accept", "manual_review_required"):
                return current_body, current_contour, decision

            if decision.action == "rerun_body_isolation":
                candidate_body = body_stage_runner.run(
                    image,
                    fg_mask=fg_mask,
                    original_image=original_image,
                    instrument_family=instrument_family,
                    geometry_authority=geometry_authority,
                    params=decision.body_retry_params,
                )

                candidate_contour = contour_stage_runner.run(
                    edges=contour_inputs["edges"],
                    alpha_mask=contour_inputs["alpha_mask"],
                    body_region=candidate_body.body_region,
                    calibration=contour_inputs["calibration"],
                    family=contour_inputs["family"],
                    image_shape=contour_inputs["image_shape"],
                )

                if self.accept_candidate(
                    original_body_result=current_body,
                    original_contour_result=current_contour,
                    candidate_body_result=candidate_body,
                    candidate_contour_result=candidate_contour,
                ):
                    _annotate_retry_attempt(
                        candidate_contour,
                        retry_reason=decision.reason,
                        retry_profile_used=_profile_name(decision.body_retry_params),
                        retry_iteration=retry_count + 1,
                        score_before=getattr(current_contour, "best_score", None),
                        score_after=getattr(candidate_contour, "best_score", None),
                        ownership_score_before=self._ownership_score(current_contour),
                        ownership_score_after=self._ownership_score(candidate_contour),
                        ownership_ok_before=self._ownership_ok(current_contour),
                        ownership_ok_after=self._ownership_ok(candidate_contour),
                    )

                    decision = replace(
                        decision,
                        candidate_body_score=candidate_body.completeness_score,
                        candidate_contour_score=getattr(candidate_contour, "best_score", None),
                    )
                    current_body = candidate_body
                    current_contour = candidate_contour
                    continue

                decision.notes.append(
                    "Body-isolation retry rejected by monotonic improvement gate."
                )
                _annotate_retry_attempt(
                    current_contour,
                    retry_reason=decision.reason,
                    retry_profile_used=_profile_name(decision.body_retry_params),
                    retry_iteration=retry_count + 1,
                    score_before=getattr(current_contour, "best_score", None),
                    score_after=getattr(candidate_contour, "best_score", None),
                    ownership_score_before=self._ownership_score(current_contour),
                    ownership_score_after=self._ownership_score(candidate_contour),
                    ownership_ok_before=self._ownership_ok(current_contour),
                    ownership_ok_after=self._ownership_ok(candidate_contour),
                )
                return current_body, current_contour, decision

            if decision.action == "rerun_contour_stage":
                candidate_contour = contour_stage_runner.run(
                    edges=contour_inputs["edges"],
                    alpha_mask=contour_inputs["alpha_mask"],
                    body_region=current_body.body_region,
                    calibration=contour_inputs["calibration"],
                    family=contour_inputs["family"],
                    image_shape=contour_inputs["image_shape"],
                    params=decision.contour_retry_params,
                )

                if self.accept_candidate(
                    original_body_result=current_body,
                    original_contour_result=current_contour,
                    candidate_body_result=current_body,
                    candidate_contour_result=candidate_contour,
                ):
                    _annotate_retry_attempt(
                        candidate_contour,
                        retry_reason=decision.reason,
                        retry_profile_used=_profile_name(decision.contour_retry_params),
                        retry_iteration=retry_count + 1,
                        score_before=getattr(current_contour, "best_score", None),
                        score_after=getattr(candidate_contour, "best_score", None),
                        ownership_score_before=self._ownership_score(current_contour),
                        ownership_score_after=self._ownership_score(candidate_contour),
                        ownership_ok_before=self._ownership_ok(current_contour),
                        ownership_ok_after=self._ownership_ok(candidate_contour),
                    )

                    decision = replace(
                        decision,
                        candidate_body_score=current_body.completeness_score,
                        candidate_contour_score=getattr(candidate_contour, "best_score", None),
                    )
                    current_contour = candidate_contour
                    continue

                decision.notes.append(
                    "Contour-stage retry rejected by monotonic improvement gate."
                )
                _annotate_retry_attempt(
                    current_contour,
                    retry_reason=decision.reason,
                    retry_profile_used=_profile_name(decision.contour_retry_params),
                    retry_iteration=retry_count + 1,
                    score_before=getattr(current_contour, "best_score", None),
                    score_after=getattr(candidate_contour, "best_score", None),
                    ownership_score_before=self._ownership_score(current_contour),
                    ownership_score_after=self._ownership_score(candidate_contour),
                    ownership_ok_before=self._ownership_ok(current_contour),
                    ownership_ok_after=self._ownership_ok(candidate_contour),
                )
                return current_body, current_contour, decision

        fallback = CoachDecisionV2(
            action="manual_review_required",
            reason="Retry loop exited unexpectedly without acceptable result.",
            retry_count=self.config.max_retries,
            original_body_score=current_body.completeness_score,
            original_contour_score=getattr(current_contour, "best_score", None),
        )
        return current_body, current_contour, fallback

    # =========================================================================
    # Multi-View Blueprint Detection and Handling
    # =========================================================================

    def is_multi_view_blueprint(
        self,
        image: np.ndarray,
        *,
        image_path: Optional[Union[str, Path]] = None,
    ) -> Tuple[bool, Optional["SegmentationResult"]]:
        """
        Detect if the input image is a multi-view blueprint.

        Returns:
            (is_multi_view, segmentation_result)
            - is_multi_view: True if 2+ distinct views detected
            - segmentation_result: SegmentationResult if detected, else None
        """
        if not MULTI_VIEW_AVAILABLE or not self.config.enable_multi_view_detection:
            return False, None

        try:
            segmenter = BlueprintViewSegmenter()

            # Prefer path-based segmentation if available
            if image_path is not None:
                result = segmenter.segment(image_path, method="auto")
            else:
                # Fallback: segment from numpy array
                result = segmenter.segment_array(image, method="auto")

            # Multi-view if 2+ views with sufficient area
            valid_views = [
                v for v in result.views
                if (v.area_ratio or 0) >= self.config.multi_view_min_area_ratio
            ]

            if len(valid_views) >= 2:
                logger.info(
                    f"Multi-view blueprint detected: {len(valid_views)} views "
                    f"(thresholds: area >= {self.config.multi_view_min_area_ratio:.2f})"
                )
                return True, result

            return False, None

        except Exception as e:
            logger.warning(f"Multi-view detection failed: {e}")
            return False, None

    def extract_per_view(
        self,
        image: np.ndarray,
        segmentation_result: "SegmentationResult",
        *,
        extraction_runner: Callable[[np.ndarray], Tuple[Any, Any]],
    ) -> List[Tuple["DetectedView", Any, Any, float]]:
        """
        Run extraction on each detected view and collect results.

        Args:
            image: Original full image
            segmentation_result: Result from is_multi_view_blueprint()
            extraction_runner: Function(view_image) -> (body_result, contour_result)

        Returns:
            List of (view, body_result, contour_result, score) sorted by score desc
        """
        results = []
        h, w = image.shape[:2]

        for idx, view in enumerate(segmentation_result.views):
            if idx >= self.config.multi_view_max_views:
                logger.info(f"Reached max views limit ({self.config.multi_view_max_views})")
                break

            if (view.area_ratio or 0) < self.config.multi_view_min_area_ratio:
                logger.debug(f"Skipping view {idx}: area ratio too small")
                continue

            # Extract view region from image
            x, y, vw, vh = view.bbox
            x = max(0, x)
            y = max(0, y)
            x2 = min(w, x + vw)
            y2 = min(h, y + vh)

            view_image = image[y:y2, x:x2].copy()

            try:
                logger.info(f"Extracting view {idx} ({view.label or 'unlabeled'}): {vw}x{vh} px")
                body_result, contour_result = extraction_runner(view_image)

                # Score the result
                contour_score = float(getattr(contour_result, "best_score", 0.0))
                body_score = float(getattr(body_result, "completeness_score", 0.0))

                # Combined score with contour emphasis
                combined_score = contour_score * 0.7 + body_score * 0.3

                results.append((view, body_result, contour_result, combined_score))
                logger.info(
                    f"View {idx} scores: contour={contour_score:.3f}, "
                    f"body={body_score:.3f}, combined={combined_score:.3f}"
                )

            except Exception as e:
                logger.warning(f"Extraction failed for view {idx}: {e}")
                continue

        # Sort by score descending
        results.sort(key=lambda x: x[3], reverse=True)
        return results

    def select_best_view_result(
        self,
        view_results: List[Tuple["DetectedView", Any, Any, float]],
    ) -> Optional[Tuple["DetectedView", Any, Any, float]]:
        """
        Select the best view result that meets quality thresholds.

        Returns:
            Best (view, body_result, contour_result, score) or None if all fail threshold
        """
        if not view_results:
            return None

        for view, body_result, contour_result, score in view_results:
            if score >= self.config.multi_view_score_threshold:
                return view, body_result, contour_result, score

        # No view meets threshold - return best anyway with warning
        logger.warning(
            f"No view meets score threshold ({self.config.multi_view_score_threshold}), "
            f"returning best available (score={view_results[0][3]:.3f})"
        )
        return view_results[0]

    def evaluate_with_multi_view(
        self,
        *,
        image: np.ndarray,
        image_path: Optional[Union[str, Path]] = None,
        extraction_runner: Callable[[np.ndarray], Tuple[Any, Any]],
        fallback_body_result: Any,
        fallback_contour_result: Any,
    ) -> Tuple[Any, Any, CoachDecisionV2]:
        """
        Pre-processing wrapper that handles multi-view blueprints.

        If the image is a multi-view blueprint:
          1. Segment into views
          2. Run extraction on each view
          3. Select best result
          4. Return with segment_views action

        If not multi-view or detection fails:
          Return fallback results for standard retry loop.

        Args:
            image: Input image as numpy array
            image_path: Optional path for better segmentation
            extraction_runner: Function(view_image) -> (body_result, contour_result)
            fallback_body_result: Body result from standard extraction
            fallback_contour_result: Contour result from standard extraction

        Returns:
            (body_result, contour_result, decision)
        """
        # Check for multi-view
        is_multi, seg_result = self.is_multi_view_blueprint(image, image_path=image_path)

        if not is_multi or seg_result is None:
            # Not multi-view - return fallback for standard retry loop
            return (
                fallback_body_result,
                fallback_contour_result,
                CoachDecisionV2(
                    action="accept",  # Will be re-evaluated by standard decide()
                    reason="Single-view image, proceeding with standard extraction.",
                    views_detected=1,
                )
            )

        # Multi-view detected - extract each view
        view_results = self.extract_per_view(
            image,
            seg_result,
            extraction_runner=extraction_runner,
        )

        if not view_results:
            # All view extractions failed
            return (
                fallback_body_result,
                fallback_contour_result,
                CoachDecisionV2(
                    action="manual_review_required",
                    reason="Multi-view blueprint detected but all view extractions failed.",
                    views_detected=seg_result.view_count,
                    notes=["Consider manual cropping to individual views."],
                )
            )

        # Select best view
        best = self.select_best_view_result(view_results)
        if best is None:
            return (
                fallback_body_result,
                fallback_contour_result,
                CoachDecisionV2(
                    action="manual_review_required",
                    reason="Multi-view blueprint detected but no view produced viable result.",
                    views_detected=seg_result.view_count,
                )
            )

        view, body_result, contour_result, score = best

        # Find index of selected view
        selected_idx = next(
            (i for i, vr in enumerate(view_results) if vr[0] is view),
            0
        )

        return (
            body_result,
            contour_result,
            CoachDecisionV2(
                action="segment_views",
                reason=f"Multi-view blueprint: selected view {selected_idx} ({view.label or 'unlabeled'}) with score {score:.3f}",
                views_detected=seg_result.view_count,
                selected_view_index=selected_idx,
                view_scores=[vr[3] for vr in view_results],
                original_body_score=float(getattr(body_result, "completeness_score", 0.0)),
                original_contour_score=float(getattr(contour_result, "best_score", 0.0)),
                notes=[
                    f"Detected {seg_result.view_count} views in blueprint.",
                    f"View types: {[v.view_type.value if v.view_type else 'unknown' for v in seg_result.views]}",
                ],
            )
        )

    def _choose_body_retry_profile(
        self,
        retry_count: int,
        preferred_profile: Optional[str] = None,
    ) -> Optional[BodyIsolationParams]:
        if preferred_profile is not None:
            for profile in self.config.body_retry_profiles:
                if profile.profile == preferred_profile:
                    return profile
        idx = min(retry_count, len(self.config.body_retry_profiles) - 1)
        return self.config.body_retry_profiles[idx]

    def _choose_contour_retry_profile(self, retry_count: int) -> Optional[StageParams]:
        if not self.config.contour_retry_profiles:
            return None
        idx = min(retry_count, len(self.config.contour_retry_profiles) - 1)
        return self.config.contour_retry_profiles[idx]

    # Normal election paths — retries are not worthwhile when the
    # contour election completed through a stable baseline decision.
    # Only "pre_merge_guarded" (merge guard override) signals instability
    # that may benefit from a retry.
    _STABLE_ELECTION_SOURCES = frozenset({"pre_merge", "post_merge"})

    @staticmethod
    def _ownership_score(contour_result: Any) -> Optional[float]:
        raw = getattr(contour_result, "ownership_score", None)
        if raw is None:
            diagnostics = getattr(contour_result, "diagnostics", None) or {}
            raw = diagnostics.get("ownership_score")
        if raw is None:
            return None
        try:
            return float(raw)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _ownership_ok(contour_result: Any) -> Optional[bool]:
        raw = getattr(contour_result, "ownership_ok", None)
        if raw is None:
            diagnostics = getattr(contour_result, "diagnostics", None) or {}
            raw = diagnostics.get("ownership_ok")
        if raw is None:
            return None
        if isinstance(raw, bool):
            return raw
        if isinstance(raw, (int, float)):
            return bool(raw)
        if isinstance(raw, str):
            lowered = raw.strip().lower()
            if lowered in {"true", "1", "yes"}:
                return True
            if lowered in {"false", "0", "no"}:
                return False
        return None

    @staticmethod
    def _contour_retry_worthwhile(contour_result: Any) -> bool:
        """
        Detect whether Stage 8 disagreement suggests a contour-only retry may help.

        Additional guard:
        If the contour stage elected its result through a stable baseline
        election path (pre_merge or post_merge), retries are not worthwhile.
        The election logic already evaluated candidate contours and selected
        the best option.

        Only retry when instability signals exist (merge guard override,
        dimensional plausibility issues, etc.).

        Compatibility: tolerates older ContourStageResult stubs that may lack
        contour_scores_pre, contour_scores_post, or export_block_issues.
        Returns False if contour_result is None or best_score is missing.
        """
        if contour_result is None:
            return False

        elected_source = getattr(contour_result, "elected_source", None)
        if elected_source in GeometryCoachV2._STABLE_ELECTION_SOURCES:
            return False

        best_score_raw = getattr(contour_result, "best_score", None)
        if best_score_raw is None:
            return False

        try:
            best_score = float(best_score_raw)
        except (TypeError, ValueError):
            return False

        if best_score >= 0.80:
            return False

        # Fall back gracefully when score lists are missing or malformed
        pre_scores = getattr(contour_result, "contour_scores_pre", None) or []
        post_scores = getattr(contour_result, "contour_scores_post", None) or []

        try:
            pre_best = max((s.score for s in pre_scores), default=best_score)
        except (TypeError, AttributeError):
            pre_best = best_score

        try:
            post_best = max((s.score for s in post_scores), default=best_score)
        except (TypeError, AttributeError):
            post_best = best_score

        # Missing issues field must degrade safely
        issues = getattr(contour_result, "export_block_issues", None) or []

        disagreement = abs(pre_best - post_best) > 0.08
        merge_tradeoff = any(
            kw in issue for issue in issues
            for kw in ("neck included", "dimension plausibility")
        )

        return disagreement or merge_tradeoff
